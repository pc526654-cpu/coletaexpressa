COLETA EXPRESSA - PAINEL ADMINISTRATIVO

Hospedagem:
- O pacote foi preparado para hospedagem com PHP.
- Envie todos os arquivos para a pasta pública do domínio.
- Abra /admin.php para entrar no painel.
- Senha padrão inicial: troque-esta-senha
- Antes de publicar, altere a senha usando a variável de ambiente COLETA_ADMIN_PASSWORD, se o seu provedor permitir.

No painel você pode alterar:
1. Link do aplicativo
2. Número do WhatsApp
3. Mensagem automática do WhatsApp

O site usa as configurações de config.php em tempo real, então não é necessário editar o HTML toda vez.
